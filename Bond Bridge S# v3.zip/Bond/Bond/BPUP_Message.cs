﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Bond_Integration
{
	public class BPUP_Message
	{
		#region Declarations
		public string B { get; set; }
		public int d { get; set; }
		public string v { get; set; }
		public string t { get; set; }
		public string i { get; set; }
		public int f { get; set; }
		public int s { get; set; }
		public int m { get; set; }
		public string x { get; set; }
		public Sidekick_BPUP_Data b { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse BPUP Message
		// 
		//****************************************************************************************
		public static BPUP_Message Parse(string json)
		{
			CrestronConsole.PrintLine("BPUP_Message.Parse - " + json);

			try
			{
				BPUP_Message item = JsonConvert.DeserializeObject<BPUP_Message>(json);
				return item;
			}
			catch (Exception ex)
			{
				string err = "Bond - BPUP_Message - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Bond - BPUP_Message - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}
	}

	public class Sidekick_BPUP_Data
	{
		#region Declarations
		[JsonProperty("event")]
		public string key_event { get; set; }
		public short key_number { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse Sidekick data
		// 
		//****************************************************************************************
		public static Sidekick_BPUP_Data Parse(string json)
		{
			CrestronConsole.PrintLine("Sidekick_BPUP_Data.Parse - " + json);

			try
			{
				Sidekick_BPUP_Data item = JsonConvert.DeserializeObject<Sidekick_BPUP_Data>(json);
				return item;
			}
			catch (Exception ex)
			{
				string err = "Bond - Sidekick_BPUP_Data - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Bond - Sidekick_BPUP_Data - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}
	}
}