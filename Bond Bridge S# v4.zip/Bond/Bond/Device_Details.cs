﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Bond_Integration
{
	public class Device_Details
	{
		#region Declarations
		public string name { get; set; }
		public string type { get; set; }
		public string location { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse sidekick details
		// 
		//****************************************************************************************
		public static Device_Details Parse(string json)
		{
			CrestronConsole.PrintLine("Device_Details.Parse - " + json);

			try
			{
				Device_Details item = JsonConvert.DeserializeObject<Device_Details>(json);
				return item;
			}
			catch (Exception ex)
			{
				string err = "Bond - Device_Details - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Bond - Device_Details - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}
	}
}