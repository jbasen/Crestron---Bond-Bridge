﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;
using System.Collections.Generic;

namespace Bond_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public short Type { get; set; }
		public string Device_ID { get; set; }
		public string Device_Name { get; set; }
		public string Device_Location { get; set; }
		public string Action_List { get; set; }
		public string msg { get; set; }

		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(short Type, string Device_ID, string Device_Name, string Device_Location, string Action_List, string msg)
		{
			#region Set Class Data Elements from Parameters
			this.Type = Type;
			this.Device_ID = Device_ID;
			this.Device_Name = Device_Name;
			this.Device_Location = Device_Location;
			this.Action_List = Action_List;
			this.msg = msg;
			#endregion
		}
	}
	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(short Type, string Device_ID, string Device_Name, string Device_Location, string Action_List, string msg)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Type, Device_ID, Device_Name, Device_Location, Action_List, msg));
		}
	}

	//Class for Device List
	class Device
	{
		public string ID;
		public string Name;
		public string Location;
		public string Action_List;

		//Constructors
		public Device()
		{
		}

		public Device(string Device_ID, string Name, string Location, string Action_list)
		{
			this.ID = Device_ID;
			this.Name = Name;
			this.Location = Location;
			this.Action_List = Action_list;
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Bond
	{
		#region Declaragions
		private static string Bond_IP = "";
		private static string Token = "";
		private static List<Device> Devices;
		private static Debug_Options Debug;
		private const short Type_Device_Info = 1;
		private const short Type_Comm_Error = 2;
		#endregion

		//****************************************************************************************
		// 
		//  Bond	-	Default Constructor
		// 
		//****************************************************************************************
		public Bond()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialize system 
		// 
		//****************************************************************************************
		public void Initialize(string Bond_IP, string Token, short Debug)
		{
			#region Save Parameters in Globals
			Bond.Bond_IP = Bond_IP;
			Bond.Token = Token;
			Set_Debug_Message_Output(Debug);
			#endregion

			#region Create holder for list of devices connected to Bond
			try
			{
				Devices = new List<Device>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Bond-Initialize - Can't create device list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Initialize - Can't create device list: " + e + "\n");
				return;
			}
			#endregion

			#region Get Devices and Pass Actions Back to Simpl
			try
			{
				Get_Devices_List();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Bond-Initialize - Can't Get List of Devices and Device Details: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Initialize - Can't Get List of Devices and Device Details: " + e + "\n");
				return;
			}
			#endregion

			Debug_Message("Initialize", "SUCCESS");
			return;
		}

		//****************************************************************************************
		// 
		//  Get_Devices_List - Get info on devices connected to Bond Bridge
		// 
		//****************************************************************************************
		private void Get_Devices_List()
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/devices/";
			Debug_Message("Get_Devices_List", "URL: " + url);
			#endregion

			#region Get List of Devices
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Get_Devices_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Devices_List", "response.ContentString: " + s);
					//remove initial hash value from returned json
					int i = s.IndexOf(",");
					s = s.Remove(0, i + 1);
					//initialize values for loop
					int open_quote = s.IndexOf("\"", 0);
					int close_curly_brace = s.IndexOf("}", 0);
					//loop until all IDs found
					while ((open_quote != -1) && (close_curly_brace != -1))
					{
						//get string with one device id
						string t = s.Substring(0, close_curly_brace + 1);
						//parse device ID
						string Device_ID = Parse_Data_Substring(t, "", "\"", "\":");
						Debug_Message("Get_Devices_List", "Device json: " + t + ", Device_ID: " + Device_ID);
						//check for error
						if (Device_ID != "")
						{
							Get_Device_Details(Device_ID);
						}
						else
						{
							string err = "Bond-Get_Devices_List - Can't Find Device_ID in json: " + t;
							CrestronConsole.PrintLine(err);
							Crestron.SimplSharp.ErrorLog.Error(err + "\n");
						}
						//discard parsed json and get indices to next device info
						s = s.Remove(0, close_curly_brace + 1);
						open_quote = s.IndexOf("\"", 0);
						close_curly_brace = s.IndexOf("}", 0);
					}
					Debug_Message("Get_Devices_List", "Number of Devices Parsed: " + Devices.Count);
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Bond-Get_Devices_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Device_Details - Get detailed info on a device connected to Bond Bridge
		// 
		//****************************************************************************************
		private void Get_Device_Details(string Device_ID)
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/devices/" + Device_ID;
			Debug_Message("Get_Device_Details", "URL: " + url);
			#endregion

			#region Request Device Details
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Get_Device_Details - http response code = " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					#region Parse JSON Response
					string s = response.ContentString;
					Debug_Message("Get_Device_Details", "response.ContentString: " + s);
					string name = Parse_Data_Substring(s, "", "\"name\":\"", "\",");
					string location = Parse_Data_Substring(s, "", "\"location\":\"", "\",");
					string action_list = Parse_Data_Substring(s, "", "\"actions\":[", "],");
					Debug_Message("Get_Device_Details", "name: " + name + ", location: " + location + ", Device_ID: " + Device_ID + ", Actions: " + action_list);
					#endregion

					#region Add to Device List
					Device Device_Data = new Device(Device_ID, name, location, action_list);
					Devices.Add(Device_Data);
					#endregion

					#region Pass Back Device Info to Simpl
					{
						const int characters_per_line = 250;
						int start_index = 0;
						int length = characters_per_line;

						//The action list could be too large for Simpl Debugger to display on a single line
						//so, we break it up into chunks of 250 characters to be printed on 1 line
						while (start_index < action_list.Length)
						{
							if ((start_index + characters_per_line) > action_list.Length)
							{
								length = action_list.Length - start_index;
							}

							string sub = action_list.Substring(start_index, length) + "\n";
							SignalChangeEvents.SerialValueChange(Type_Device_Info, Device_ID, name, location, sub, "");
							start_index += characters_per_line;
						}
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Bond-Get_Device_Details - Error Getting Device Details: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Device_Action	-	Sends a device Action (on, off, etc.) to the Bond Bridge
		// 
		//****************************************************************************************
		public void Send_Device_Action(string Device_ID, string Action, string Argument, string State_Variable_Name, string State_Variable_Value)
		{
			Debug_Message("Send_Device_Action", "Action: " + Action + ", Argument: " + Argument + ", Device_ID: " + Device_ID);

			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/devices/" + Device_ID +"/actions/" + Action;
			Debug_Message("Send_Device_Action", "URL: " + url);
			#endregion
			
			#region Send Action
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Put;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));
				request.Header.AddHeader(new HttpHeader("content-type", "application/x-www-form-urlencoded"));
				//Add optional parts of header
				if (Argument != "")
				{
					request.ContentString = "{\"argument\": " + Argument + "}";
					
				}
				if ((State_Variable_Name != "") && (State_Variable_Value != ""))
				{
					request.ContentString = "{\"" + State_Variable_Name + "\": " + State_Variable_Value + "}";
				}
				if ((Argument == "") && (State_Variable_Name == "") && (State_Variable_Value == ""))
				{
					request.ContentString = "{}";
				}

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Send_Device_Action - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}

			}
			catch (Exception e)
			{
				string err = "Bond-Send_Device_Action - Error Sending Device Action: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion

		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Bond-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Bond-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Bond-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Bond-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Bond-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			if (s.Substring(index1, index2 - index1) == null)
			{
				//never pass back null
				return "";
			}
			else
			{
				return s.Substring(index1, index2 - index1);
			}
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Bond.Debug = Debug_Options.None;
					break;

				case 1:
					Bond.Debug = Debug_Options.Console;
					break;

				case 2:
					Bond.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Bond.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Bond-" + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Bond-" + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

		//****************************************************************************************
		// 
		//  Report_Communications_Error	-	Sends a communications error information
		//									to the comm manager module for reporting
		// 
		//****************************************************************************************
		private void Report_Communications_Error(string msg)
		{
			SignalChangeEvents.SerialValueChange(Type_Comm_Error, "", "", "", "", msg);
		}

	}
}
