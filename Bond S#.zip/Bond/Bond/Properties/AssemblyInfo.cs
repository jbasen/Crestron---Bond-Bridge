﻿using System.Reflection;

[assembly: AssemblyTitle("Bond")]
[assembly: AssemblyCompany("HP Inc.")]
[assembly: AssemblyProduct("Bond")]
[assembly: AssemblyCopyright("Copyright © HP Inc. 2020")]
[assembly: AssemblyVersion("1.0.0.*")]

