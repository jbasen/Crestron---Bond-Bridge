﻿using System;
using System.Text;
using Crestron.SimplSharp;                          				// For Basic SIMPL# Classes
using Crestron.SimplSharp.Net.Http;
using System.Collections.Generic;
using Crestron.SimplSharp.CrestronSockets;

namespace Bond_Integration
{
	#region Classes
	//Event Classes
	public class SerialChangeEventArgs : EventArgs
	{
		public short Type { get; set; }
		public string Device_ID { get; set; }
		public string Device_Name { get; set; }
		public string Device_Location { get; set; }
		public string Group_ID { get; set; }
		public string Group_Name { get; set; }
		public string Action_List { get; set; }
		public string msg { get; set; }
		public string key_event { get; set; }
		public short key_number { get; set; }


		public SerialChangeEventArgs()
		{
		}

		public SerialChangeEventArgs(short Type, string Device_ID, string Device_Name, string Device_Location, string Group_ID, string Group_Name, string Action_List, string msg,
			string key_event, short key_number)
		{
			#region Set Class Data Elements from Parameters
			this.Type = Type;
			this.Device_ID = Device_ID;
			this.Device_Name = Device_Name;
			this.Device_Location = Device_Location;
			this.Group_ID = Group_ID;
			this.Group_Name = Group_Name;
			this.Action_List = Action_List;
			this.msg = msg;
			this.key_event = key_event;
			this.key_number = key_number;
			#endregion
		}
	}

	public static class SignalChangeEvents
	{
		public static event SerialChangedEventHandler onSerialValueChange;

		public static void SerialValueChange(short Type, string Device_ID, string Device_Name, string Device_Location, string Group_ID, string Group_Name, string Action_List, string msg, string key_event, short key_number)
		{
			SignalChangeEvents.onSerialValueChange(new SerialChangeEventArgs(Type, Device_ID, Device_Name, Device_Location, Group_ID, Group_Name, Action_List, msg, key_event, key_number));
		}
	}

	//Class for Device List
	class Device
	{
		public string ID;
		public string Name;
		public string Location;
		public string Action_List;
		public string Type;
		public int Keys;
		public string Model;

		//Constructors
		public Device()
		{
		}

		public Device(string Device_ID, string Name, string Location, string Action_list)
		{
			this.ID = Device_ID;
			this.Name = Name;
			this.Location = Location;
			this.Action_List = Action_list;
			this.Type = "DEVICE";
			this.Keys = 0;
			this.Model = "";
		}

		public Device(string Device_ID, string Name, string Location, int Keys, string Model)
		{
			this.ID = Device_ID;
			this.Name = Name;
			this.Location = Location;
			this.Action_List = "";
			this.Type = "SIDEKICK";
			this.Keys = Keys;
			this.Model = Model;
		}
	}

	//Class for Device List
	class Group
	{
		public string ID;
		public string Name;
		public string Action_List;

		//Constructors
		public Group()
		{
		}

		public Group(string Device_ID, string Name, string Action_list)
		{
			this.ID = Device_ID;
			this.Name = Name;
			this.Action_List = Action_list;
		}
	}
	#endregion

	#region Delegates
	public delegate void SerialChangedEventHandler(SerialChangeEventArgs e);
	#endregion

	#region Enum
	enum Debug_Options
	{
		None,								//Don't do anything with debug information
		Console,							//Output debug information to the console
		Error_Log,							//Send debug information to the error log
		Both								//Send debug infomation to both the console and error log
	};
	#endregion

	public class Bond
	{
		#region Declaragions
		private static string Bond_IP = "";
		private static string Token = "";
		private static List<Device> Devices;
		private static List<Group> Groups;
		private static Debug_Options Debug;
		private const short Type_Device_Info = 1;
		private const short Type_Comm_Error = 2;
		private const short Type_Sidekick_Info = 3;
		private const short Type_Group_Info = 4;
		private const int BPUP_Port = 30007;
		private static bool Support_Sidekicks;
		private static UDPServer BPUP_Server;
		#endregion

		//****************************************************************************************
		// 
		//  Bond	-	Default Constructor
		// 
		//****************************************************************************************
		public Bond()
		{
		}

		//****************************************************************************************
		// 
		//  Initialize	-	Initialize system 
		// 
		//****************************************************************************************
		public void Initialize(string Bond_IP, string Token, short Support_Sidekicks, short Debug)
		{
			#region Save Parameters in Globals
			Bond.Bond_IP = Bond_IP;
			Bond.Token = Token;
			Bond.Support_Sidekicks = (Support_Sidekicks == 1) ? true : false;
			Set_Debug_Message_Output(Debug);
			#endregion

			#region Create holder for list of devices connected to Bond
			try
			{
				Devices = new List<Device>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Bond-Initialize - Can't create device list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Initialize - Can't create device list: " + e + "\n");
				return;
			}
			#endregion

			#region Create holder for list of groups connected to Bond
			try
			{
				Groups = new List<Group>();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Bond-Initialize - Can't create group list: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Initialize - Can't create group list: " + e + "\n");
				return;
			}
			#endregion

			#region Get Devices and Pass Actions Back to Simpl
			try
			{
				Get_Devices_List();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Bond-Initialize - Can't Get List of Devices and Device Details: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Initialize - Can't Get List of Devices and Device Details: " + e + "\n");
				return;
			}
			#endregion

			#region Get Groups and Pass Actions Back to Simpl
			try
			{
				Get_Groups_List();
			}
			catch (Exception e)
			{
				CrestronConsole.PrintLine("Bond-Initialize - Can't Get List of Groups and Group Details: " + e);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Initialize - Can't Get List of Groups and Group Details: " + e + "\n");
				return;
			}
			#endregion

			if (Bond.Support_Sidekicks == true)
			{
				#region Initialize BPUP Support for Sidekicks
				Patch_Bridge();
				Start_BPUP_Receiver(Bond_IP, BPUP_Port);

				#endregion
			}

			Debug_Message("Initialize", "SUCCESS");
			return;
		}

		//****************************************************************************************
		// 
		//  Get_Devices_List - Get info on devices connected to Bond Bridge
		// 
		//****************************************************************************************
		private void Get_Devices_List()
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/devices/";
			Debug_Message("Get_Devices_List", "URL: " + url);
			#endregion

			#region Get List of Devices
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Get_Devices_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Devices_List", "response.ContentString: " + s);
					if (s.Length > 1)
					{
						//remove initial hash value from returned json
						int i = s.IndexOf(",");
						s = s.Remove(0, i + 1);
						//check for weird __ json field
						if (s.IndexOf("__") != -1)
						{
							//remove undocumented json field
							i = s.IndexOf(",");
							s = s.Remove(0, i + 1);
						}
						//initialize values for loop
						int open_quote = s.IndexOf("\"", 0);
						int close_curly_brace = s.IndexOf("}", 0);
						//loop until all IDs found
						while ((open_quote != -1) && (close_curly_brace != -1))
						{
							//get string with one device id
							string t = s.Substring(0, close_curly_brace + 1);
							//parse device ID
							string Device_ID = Parse_Data_Substring(t, "", "\"", "\":");
							Debug_Message("Get_Devices_List", "Device json: " + t + ", Device_ID: " + Device_ID);
							//check for error
							if (Device_ID != "")
							{
								Get_Device_Details(Device_ID);
							}
							else
							{
								string err = "Bond-Get_Devices_List - Can't Find Device_ID in json: " + t;
								CrestronConsole.PrintLine(err);
								Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							}
							//discard parsed json and get indices to next device info
							s = s.Remove(0, close_curly_brace + 1);
							open_quote = s.IndexOf("\"", 0);
							close_curly_brace = s.IndexOf("}", 0);
						}
						Debug_Message("Get_Devices_List", "Number of Devices Parsed: " + Devices.Count);
					}
					else
					{
						Debug_Message("Get_Devices_List", "Number of Devices Parsed: 0");
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Bond-Get_Devices_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Device_Details - Get detailed info on a device connected to Bond Bridge
		// 
		//****************************************************************************************
		private void Get_Device_Details(string Device_ID)
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/devices/" + Device_ID;
			Debug_Message("Get_Device_Details", "URL: " + url);
			#endregion

			#region Request Device Details
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Get_Device_Details - http response code = " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					#region Parse JSON Response
					string s = response.ContentString;
					Debug_Message("Get_Device_Details", "response.ContentString: " + s);
					Device_Details item = Device_Details.Parse(s);
					string action_list = Parse_Data_Substring(s, "", "\"actions\":[", "],");
					Debug_Message("Get_Device_Details", "name: " + item.name + ", location: " + item.location + ", Device_ID: " + Device_ID + ", Actions: " + action_list);
					#endregion

					#region Add to Device List
					Device Device_Data = new Device(Device_ID, item.name, item.location, action_list);
					Devices.Add(Device_Data);
					#endregion

					#region Pass Back Device Info to Simpl
					{
						const int characters_per_line = 250;
						int start_index = 0;
						int length = characters_per_line;

						//The action list could be too large for Simpl Debugger to display on a single line
						//so, we break it up into chunks of 250 characters to be printed on 1 line
						while (start_index < action_list.Length)
						{
							if ((start_index + characters_per_line) > action_list.Length)
							{
								length = action_list.Length - start_index;
							}

							string sub = action_list.Substring(start_index, length) + "\n";
							SignalChangeEvents.SerialValueChange(Type_Device_Info, Device_ID, item.name, item.location, "", "", sub, "", "", 0);
							start_index += characters_per_line;
						}
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Bond-Get_Device_Details - Error Getting Device Details: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Device_Action	-	Sends a device Action (on, off, etc.) to the Bond Bridge
		// 
		//****************************************************************************************
		public void Send_Device_Action(string Device_ID, string Action, string Argument)
		{
			Debug_Message("Send_Device_Action", "Action: " + Action + ", Argument: " + Argument + ", Device_ID: " + Device_ID);

			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/devices/" + Device_ID +"/actions/" + Action;
			Debug_Message("Send_Device_Action", "URL: " + url);
			#endregion
			
			#region Send Action
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Put;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));
				request.Header.AddHeader(new HttpHeader("content-type", "application/x-www-form-urlencoded"));
				//Add optional parts of header
				if (Argument != "")
				{
					request.ContentString = "{\"argument\": " + Argument + "}";
					
				}
				else
				{
					request.ContentString = "{}";
				}
				Debug_Message("Send_Device_Action", "ContentString: " + request.ContentString);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Send_Device_Action - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}

			}
			catch (Exception e)
			{
				string err = "Bond-Send_Device_Action - Error Sending Device Action: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion

		}

		//****************************************************************************************
		// 
		//  Get_Groups_List - Get info on defined groups
		// 
		//****************************************************************************************
		private void Get_Groups_List()
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/groups/";
			Debug_Message("Get_Groups_List", "URL: " + url);
			#endregion

			#region Get List of Devices
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Get_Groups_List - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					#region Parse Device IDs
					//Extract Device ID's from json
					string s = response.ContentString;
					Debug_Message("Get_Groups_List", "response.ContentString: " + s);
					if (s.Length > 1)
					{
						//remove initial hash value from returned json
						int i = s.IndexOf(",");
						s = s.Remove(0, i + 1);
						//check for weird __ json field
						if (s.IndexOf("__") != -1)
						{
							//remove undocumented json field
							i = s.IndexOf(",");
							s = s.Remove(0, i + 1);
						}
						//initialize values for loop
						int open_quote = s.IndexOf("\"", 0);
						int close_curly_brace = s.IndexOf("}", 0);
						//loop until all IDs found
						while ((open_quote != -1) && (close_curly_brace != -1))
						{
							//get string with one device id
							string t = s.Substring(0, close_curly_brace + 1);
							//parse device ID
							string Device_ID = Parse_Data_Substring(t, "", "\"", "\":");
							Debug_Message("Get_Groups_List", "Device json: " + t + ", Device_ID: " + Device_ID);
							//check for error
							if (Device_ID != "")
							{
								Get_Group_Details(Device_ID);
							}
							else
							{
								string err = "Bond-Get_Groups_List - Can't Find Device_ID in json: " + t;
								CrestronConsole.PrintLine(err);
								Crestron.SimplSharp.ErrorLog.Error(err + "\n");
							}
							//discard parsed json and get indices to next device info
							s = s.Remove(0, close_curly_brace + 1);
							open_quote = s.IndexOf("\"", 0);
							close_curly_brace = s.IndexOf("}", 0);
						}
						Debug_Message("Get_Groups_List", "Number of Devices Parsed: " + Devices.Count);
					}
					else
					{
						Debug_Message("Get_Groups_List", "Number of Devices Parsed: 0");
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Bond-Get_Groups_List - Error Getting List of Devices: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Get_Group_Details - Get detailed info on a group
		// 
		//****************************************************************************************
		private void Get_Group_Details(string Group_ID)
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/groups/" + Group_ID;
			Debug_Message("Get_Group_Details", "URL: " + url);
			#endregion

			#region Request Device Details
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Get;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Get_Group_Details - http response code = " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}
				else
				{
					#region Parse JSON Response
					string s = response.ContentString;
					Debug_Message("Get_Group_Details", "response.ContentString: " + s);
					Group_Details item = Group_Details.Parse(s);
					string action_list = Parse_Data_Substring(s, "", "\"actions\":[", "],");
					Debug_Message("Get_Group_Details", "name: " + item.name + ", Actions: " + action_list);
					#endregion

					#region Add to Device List
					Group Group_Data = new Group(Group_ID, item.name, action_list);
					Groups.Add(Group_Data);
					#endregion

					#region Pass Back Device Info to Simpl
					{
						const int characters_per_line = 250;
						int start_index = 0;
						int length = characters_per_line;

						//The action list could be too large for Simpl Debugger to display on a single line
						//so, we break it up into chunks of 250 characters to be printed on 1 line
						while (start_index < action_list.Length)
						{
							if ((start_index + characters_per_line) > action_list.Length)
							{
								length = action_list.Length - start_index;
							}

							string sub = action_list.Substring(start_index, length) + "\n";
							SignalChangeEvents.SerialValueChange(Type_Group_Info, "", "", "", Group_ID, item.name, sub, "", "", 0);
							start_index += characters_per_line;
						}
					}
					#endregion
				}
			}
			catch (Exception e)
			{
				string err = "Bond-Get_Group_Details - Error Getting Device Details: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Send_Group_Action	-	Sends a group Action (on, off, etc.) to the Bond Bridge
		// 
		//****************************************************************************************
		public void Send_Group_Action(string Group_ID, string Action, string Argument)
		{
			Debug_Message("Send_Group_Action", "Action: " + Action + ", Argument: " + Argument + ", Device_ID: " + Group_ID);

			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/groups/" + Group_ID + "/actions/" + Action;
			Debug_Message("Send_Group_Action", "URL: " + url);
			#endregion

			#region Send Action
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Put;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));
				request.Header.AddHeader(new HttpHeader("content-type", "application/x-www-form-urlencoded"));
				//Add optional parts of header
				if (Argument != "")
				{
					request.ContentString = "{\"argument\": " + Argument + "}";

				}
				else
				{
					request.ContentString = "{}";
				}
				Debug_Message("Send_Group_Action", "ContentString: " + request.ContentString);

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond-Send_Group_Action - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}

			}
			catch (Exception e)
			{
				string err = "Bond-Send_Group_Action - Error Sending Device Action: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion

		}

		//****************************************************************************************
		// 
		//  Patch_Bridge	-	Sends command to bridge to continuously broadcast	
		// 
		//****************************************************************************************
		private void Patch_Bridge()
		{
			#region Create url
			//Create url
			string url = "http://" + Bond.Bond_IP + "/v2/api/bpup";
			Debug_Message("Patch_Bridge", "URL: " + url);
			#endregion

			#region Send Action
			try
			{
				//Create http client
				HttpClient client = new HttpClient();
				//client.Verbose = true;
				HttpClientRequest request = new HttpClientRequest();
				HttpClientResponse response;

				//Send http client request
				request.KeepAlive = false;
				request.Url.Parse(url);
				request.RequestType = Crestron.SimplSharp.Net.Http.RequestType.Patch;
				request.Header.AddHeader(new HttpHeader("Accept", "*/*"));
				request.Header.AddHeader(new HttpHeader("BOND-Token", Bond.Token));
				request.Header.AddHeader(new HttpHeader("content-type", "application/x-www-form-urlencoded"));
				//Add optional parts of header
				request.ContentString = "{\"broadcast\":true}";

				//Get response
				response = client.Dispatch(request);
				if (response.Code < 200 || response.Code >= 300)
				{
					// server threw a error.
					string err = "Bond - Patch_Bridge - http response code: " + response.Code;
					CrestronConsole.PrintLine(err);
					Crestron.SimplSharp.ErrorLog.Error(err + "\n");
					Report_Communications_Error(err);
				}

			}
			catch (Exception e)
			{
				string err = "Bond - Patch_Bridge - Error Sending Device Action: " + e;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
			#endregion
		}

		//****************************************************************************************
		// 
		//  Start_BPUP_Receiver	-	Startup Receiver to receive BPUP Messages
		// 
		//****************************************************************************************
		private void Start_BPUP_Receiver(string Bond_IP, int BPUP_Port)
		{
			try
			{
				BPUP_Server = new UDPServer(IPAddress.Any, BPUP_Port, 20000);
				BPUP_Server.EnableUDPServer();
				BPUP_Server.ReceiveDataAsync(BPUP_Receiver_Packet_Received);
			}
			catch (Exception ex)
			{
				string err = "Bond-Start_BPUP_Receiver - Error Starting BPUP Receiver: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);
			}
		}

		//****************************************************************************************
		// 
		//  ReceiverPacketReceived	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private void BPUP_Receiver_Packet_Received(UDPServer my_UDP_Server, int Byte_Count)
		{
			try
			{
				Debug_Message("BPUP_Receiver_Packet_Received", "Number of Bytes Received: " + Byte_Count + ", From: " + my_UDP_Server.IPAddressLastMessageReceivedFrom);

				Byte[] data = (new List<byte>(my_UDP_Server.IncomingDataBuffer)).ToArray();
				String str = System.Text.Encoding.ASCII.GetString(data, 0, Byte_Count);

				#region Parse message if from Bond Bridge or a Sidekick
				if ((my_UDP_Server.IPAddressLastMessageReceivedFrom == Bond_IP) || (str.IndexOf("sidekicks", StringComparison.OrdinalIgnoreCase) >= 0))
				{

					Debug_Message("BPUP_Receiver_Packet_Received", "Data: " + str);

					BPUP_Message message = BPUP_Message.Parse(str);
					if (string.IsNullOrEmpty(message.t) == false)
					{
						if (message.t.IndexOf("sidekicks", StringComparison.OrdinalIgnoreCase) >= 0)
						{
							string Sidekick_ID = Parse_Data_Substring(message.t, "", "sidekicks/", "/keystream");//Get Sidekick ID from BPUP message

							Debug_Message("BPUP_Receiver_Packet_Received", "Sidekick_ID: " + Sidekick_ID + ", key_event = " + message.b.key_event + ", key_number = " + message.b.key_number);

							SignalChangeEvents.SerialValueChange(Type_Sidekick_Info, Sidekick_ID, "", "", "", "", "", "", message.b.key_event, message.b.key_number);
						}
					}
				}
				#endregion
			}
			catch (Exception ex)
			{
				string err = "Bond-BPUP_Receiver_Packet_Received - Error Retreiving BPUP_Message: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				Report_Communications_Error(err);

				CrestronConsole.PrintLine("Bond-BPUP_Receiver_Packet_Received - \n" + ex.StackTrace);
			}

			my_UDP_Server.ReceiveDataAsync(BPUP_Receiver_Packet_Received);
		}

		//****************************************************************************************
		// 
		//  Parse_Data_Substring	-	Parse Data Element from Json
		// 
		//****************************************************************************************
		private string Parse_Data_Substring(string s, string section, string id, string ending_char)
		{
			int index1, index2, section_index;

			//if data element located within a specific section of json, go to that section
			if (section != "")
			{
				section_index = s.IndexOf(section, 0);
				if (section_index == -1)
				{
					//CrestronConsole.PrintLine("Bond-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					//Crestron.SimplSharp.ErrorLog.Error("Bond-Parse_Data_Substring - Unable to Locate " + section + " in " + s);
					return "";
				}
				else
				{
					section_index += section.Length;
				}
			}
			else
			{
				section_index = 0;
			}

			//get index to start of value
			index1 = s.IndexOf(id, section_index);
			if (index1 == -1)
			{
				//CrestronConsole.PrintLine("Bond-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				//Crestron.SimplSharp.ErrorLog.Error("Bond-Parse_Data_Substring - Unable to Locate " + id + " in " + s);
				return "";
			}
			else
			{
				index1 += id.Length;
			}

			//get index to end of value
			index2 = s.IndexOf(ending_char, (index1 + 1));
			if (index2 == -1)
			{
				CrestronConsole.PrintLine("Bond-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				Crestron.SimplSharp.ErrorLog.Error("Bond-Parse_Data_Substring - Unable to Locate terminating " + ending_char + " for " + id + " in " + s);
				return "";
			}

			//get value substring and pass it back
			if (s.Substring(index1, index2 - index1) == null)
			{
				//never pass back null
				return "";
			}
			else
			{
				return s.Substring(index1, index2 - index1);
			}
		}

		//****************************************************************************************
		// 
		//  Set_Debug_Message_Output	-	Save whether debug messages will be output
		//									to console, error log, both, or not sent
		//									0 = None, 1 = Console, 2 = Error Log, 3 = Both
		// 
		//****************************************************************************************
		public void Set_Debug_Message_Output(short Debug)
		{
			//Save debug message setting as an enum
			switch (Debug)
			{
				case 0:
					Bond.Debug = Debug_Options.None;
					break;

				case 1:
					Bond.Debug = Debug_Options.Console;
					break;

				case 2:
					Bond.Debug = Debug_Options.Error_Log;
					break;

				case 3:
					Bond.Debug = Debug_Options.Both;
					break;
			}
		}

		//****************************************************************************************
		// 
		//  Debug_Message	-	Send Debug Message to Console or Error Log
		//						Depending on Selection
		// 
		//****************************************************************************************
		private void Debug_Message(string Name, string s)
		{
			const int characters_per_line = 250;
			int start_index = 0;
			int length = characters_per_line;

			//json responses are too large for Simpl Debugger to display on a single line
			//so, we break them up into chunks of 250 characters to be printed on 1 line
			while (start_index < s.Length)
			{
				if ((start_index + characters_per_line) > s.Length)
				{
					length = s.Length - start_index;
				}

				string sub = s.Substring(start_index, length);

				if ((Debug == Debug_Options.Console) || (Debug == Debug_Options.Both))
				{
					CrestronConsole.PrintLine("Bond-" + Name + " - " + sub);
				}

				if ((Debug == Debug_Options.Error_Log) || (Debug == Debug_Options.Both))
				{
					Crestron.SimplSharp.ErrorLog.Notice("Bond-" + Name + " - " + sub + "\n");
				}

				start_index += characters_per_line;
			}
		}

		//****************************************************************************************
		// 
		//  Report_Communications_Error	-	Sends a communications error information
		//									to the comm manager module for reporting
		// 
		//****************************************************************************************
		private void Report_Communications_Error(string msg)
		{
			SignalChangeEvents.SerialValueChange(Type_Comm_Error, "", "", "", "", "", "", msg, "", 0);
		}
	}
}
