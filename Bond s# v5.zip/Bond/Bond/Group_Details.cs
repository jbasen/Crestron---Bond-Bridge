﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Crestron.SimplSharp;
using Newtonsoft.Json;

namespace Bond_Integration
{
	public class Group_Details
	{
		#region Declarations
		public string name { get; set; }
		#endregion

		//****************************************************************************************
		// 
		//  Parse	-   Parse sidekick details
		// 
		//****************************************************************************************
		public static Group_Details Parse(string json)
		{
			CrestronConsole.PrintLine("Group_Details.Parse - " + json);

			try
			{
				Group_Details item = JsonConvert.DeserializeObject<Group_Details>(json);
				return item;
			}
			catch (Exception ex)
			{
				string err = "Bond - Group_Details - Parsing JSON: " + ex;
				CrestronConsole.PrintLine(err);
				Crestron.SimplSharp.ErrorLog.Error(err + "\n");
				CrestronConsole.PrintLine("Bond - Group_Details - Parsing JSON - \n" + ex.StackTrace);
				return null;
			}
		}

	}
}